// Import our custom CSS
import '../scss/styles.scss'

// Import all of Bootstrap's JS
//import 'bootstrap/js/dist/collapse';
//import Collapse from 'bootstrap/js/dist/collapse'
//import  Alert  from 'bootstrap/js/dist/alert'
//const collapse = Collapse.getOrCreateInstance(document.getElementById("collapseOne"))
//console.log(collapse)