import { PurgeCSS } from "purgecss";
const purgeCSSResults = await new PurgeCSS().purge({
  content: ["**/dist/*.html"],
  css: ["**/dist/assets/*.css"],
});
console.log(purgeCSSResults)